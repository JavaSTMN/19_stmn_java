package exercice2;

public interface IRaster {
	int[][] getValues();
}
